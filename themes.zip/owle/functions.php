<?php

    include('customizer.php');

    //отключаем админ бар
    add_filter('show_admin_bar', '__return_false');

    //убираем отступ под админ бар
    function remove_admin_login_header() {
        remove_action('wp_head', '_admin_bar_bump_cb');
    }
    add_action('get_header', 'remove_admin_login_header');

    //включить миниатюры постов
    add_theme_support( 'post-thumbnails' );

    //включить виджеты
    add_theme_support( 'customize-selective-refresh-widgets' );

    //мультиязычность
    function setup_theme(){
        load_theme_textdomain('owletex-landing', get_template_directory() . '/languages');
    }
    add_action('after_setup_theme', 'setup_theme');

    //инициализации меню
    function register_my_menu() {
        register_nav_menu('header-menu',__( 'Header Menu' ));
    }
    add_action( 'init', 'register_my_menu' );

    function register_my_menus() {
        register_nav_menus(
            array(
                'header-menu' => __( 'Header Menu' )
            )
        );
    }
    add_action( 'init', 'register_my_menus' );

    if ( function_exists( 'pll_register_string' ) ) :
        function owletex_child_pll_register_string() {
            pll_register_string( 'header-h1', get_theme_mod( 'header-h1', 'Краткое описание сервиса в одном предложении' ), 'Theme: Owletex Child', true );
            pll_register_string( 'header-p', get_theme_mod( 'header-p', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );

            pll_register_string( 'advantages-h3-1', get_theme_mod( 'advantages-h3-1', 'Работа с ведущими биржами в одном окне' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-p-1', get_theme_mod( 'advantages-p-1', 'Сервис позволяет работать одновременно с несколькими ведущими криптовалютными биржами. Вы можете подключить все свои аккаунты и производить торговые операции в одном интерфейсе как с каждой биржей в отдельности, так и производить трансфер активов между ними' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-h3-2', get_theme_mod( 'advantages-h3-2', 'Возможность автоматизированной торговли (боты)' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-p-2', get_theme_mod( 'advantages-p-2', 'С Owletex вы имеете возможность использования системы автоматизированной торговли, которая будет зарабатывать деньги без вашего непосредственного участия. Внутри сервиса вы можете создавать и настраивать неограниченное количество трейдинг-ботов, каждый из которых может реализовывать отдельные торговые стратегии для различных криптовалютных активов.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-h3-3', get_theme_mod( 'advantages-h3-3', 'Наличие демо-аккаунта' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-p-3', get_theme_mod( 'advantages-p-3', 'Торговля криптовалютами - рискованное занятие, постоянно требующее держать обе руки на пульсе валютного рынка. Если вы не уверены в разрабатываемых стратегиях, вы можете протестировать их внутри нашего сервиса в тестовом режиме перед "боевым" запуском.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-h3-4', get_theme_mod( 'advantages-h3-4', 'Сквозная аналитика портфеля' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-p-4', get_theme_mod( 'advantages-p-4', 'С помощью гибких инструментов внутри сервиса вы сможете производить ежедневную аналитику вашего заработка, расходов и состояния портфеля. Также имеется возможность слежения за состоянием криптовалютного рынка в мире. С помощью несложных действий вы сможете производить пополнение балансов бирж, перераспределять активы и осуществлять ребалансировку вашего портфеля по каждой отдельной бирже.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-h3-5', get_theme_mod( 'advantages-h3-5', 'Быстрая техподдержка' ), 'Theme: Owletex Child', true );
            pll_register_string( 'advantages-p-5', get_theme_mod( 'advantages-p-5', 'И, хотя система Owletex была разработана так, чтобы она была понятна даже для начинающего трейдера, мы понимаем, что в процессе работы могут возникать самые разнообразные вопросы касаемо самого сервиса и трейдинга с помощью него. Наша техподдержка готова оперативно помочь и ответить на любые интересующие вас вопросы.' ), 'Theme: Owletex Child', true );

            pll_register_string( 'scheme-li-1', get_theme_mod( 'scheme-li-1', 'Регистрируйтесь' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-p-1', get_theme_mod( 'scheme-p-1', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-li-2', get_theme_mod( 'scheme-li-2', 'Подключаете биржи' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-p-2', get_theme_mod( 'scheme-p-2', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-li-3', get_theme_mod( 'scheme-li-3', 'Выбираете тариф' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-p-3', get_theme_mod( 'scheme-p-3', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-li-4', get_theme_mod( 'scheme-li-4', 'Работаете с сервисом' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-p-4', get_theme_mod( 'scheme-p-4', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-li-5', get_theme_mod( 'scheme-li-5', 'Получаете профит' ), 'Theme: Owletex Child', true );
            pll_register_string( 'scheme-p-5', get_theme_mod( 'scheme-p-5', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );

            pll_register_string( 'features-h-1', get_theme_mod( 'features-h-1', 'Первая возможность' ), 'Theme: Owletex Child', true );
            pll_register_string( 'features-p-1', get_theme_mod( 'features-p-1', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'features-h-2', get_theme_mod( 'features-h-2', 'Вторая возможность' ), 'Theme: Owletex Child', true );
            pll_register_string( 'features-p-2', get_theme_mod( 'features-p-2', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'features-h-3', get_theme_mod( 'features-h-3', 'Третья возможность' ), 'Theme: Owletex Child', true );
            pll_register_string( 'features-p-3', get_theme_mod( 'features-p-3', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития. Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );

            pll_register_string( 'footer-1', get_theme_mod( 'footer-1', 'Таким образом дальнейшее развитие различных форм деятельности влечет за собой процесс внедрения и модернизации направлений прогрессивного развития.' ), 'Theme: Owletex Child', true );
            pll_register_string( 'footer-2', get_theme_mod( 'footer-2', '@2018 Owletex. Все права защищены' ), 'Theme: Owletex Child', true );
        }
        add_action( 'after_setup_theme', 'owletex_child_pll_register_string' );
    endif;

    add_action('init', function() {
        pll_register_string('owletex-landing', 'Загрузить ещё');
        pll_register_string('owletex-landing', 'Главная');
        pll_register_string('owletex-landing', 'Новости');
        pll_register_string('owletex-landing', 'Контакты');
        pll_register_string('owletex-landing', 'Тарифы');
        pll_register_string('owletex-landing', 'Главная страница');
        pll_register_string('owletex-landing', 'Обратная связь');
        pll_register_string('owletex-landing', 'О нас');
    });
